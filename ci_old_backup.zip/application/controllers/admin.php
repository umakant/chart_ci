<?php

class Admin extends MY_Controller {
	

	public function dashboard()
	{
		$this->load->library('pagination');

		$config = [
			'base_url'			=>	base_url('admin/dashboard'),
			'per_page'			=>	5,
			'total_rows'		=>	$this->articles->num_rows(),
			'full_tag_open'		=>	"<ul class='pagination'>",
			'full_tag_close'	=>	"</ul>",
			'first_tag_open'	=>	'<li>',
			'first_tag_close'	=>	'</li>',
			'last_tag_open'		=>	'<li>',
			'last_tag_close'	=>	'</li>',
			'next_tag_open'		=>	'<li>',
			'next_tag_close'	=>	'</li>',
			'prev_tag_open'		=>	'<li>',
			'prev_tag_close'	=>	'</li>',
			'num_tag_open'		=>	'<li>',
			'num_tag_close'		=>	'</li>',
			'cur_tag_open'		=>	"<li class='active'><a>",
			'cur_tag_close'		=>	'</a></li>',
		];

		$this->pagination->initialize($config);

		$articles = $this->articles->articles_list( $config['per_page'], $this->uri->segment(3) );

		$this->load->view('admin/dashboard', ['articles'=>$articles]);
	}

	public function add_article()
	{
		$this->load->view('admin/add_article');
	}

	public function view_articles()
	{
		$this->load->library('pagination');

		$config = [
			'base_url'			=>	base_url('admin/view_articles'),
			'per_page'			=>	5,
			'total_rows'		=>	$this->articles->num_rows(),
			'full_tag_open'		=>	"<ul class='pagination'>",
			'full_tag_close'	=>	"</ul>",
			'first_tag_open'	=>	'<li>',
			'first_tag_close'	=>	'</li>',
			'last_tag_open'		=>	'<li>',
			'last_tag_close'	=>	'</li>',
			'next_tag_open'		=>	'<li>',
			'next_tag_close'	=>	'</li>',
			'prev_tag_open'		=>	'<li>',
			'prev_tag_close'	=>	'</li>',
			'num_tag_open'		=>	'<li>',
			'num_tag_close'		=>	'</li>',
			'cur_tag_open'		=>	"<li class='active'><a>",
			'cur_tag_close'		=>	'</a></li>',
		];

		$this->pagination->initialize($config);

		$articles = $this->articles->articles_list( $config['per_page'], $this->uri->segment(3) );

		$this->load->view('admin/view_articles', ['articles'=>$articles]);
	}
	public function store_article()
	{
		$config = [
			'upload_path'	=>		'./uploads',
			'allowed_types'	=>		'jpg|gif|png|jpeg',
		];
		$this->load->library('upload', $config);

		$this->load->library('form_validation');
		if( $this->form_validation->run('add_article_rules') && $this->upload->do_upload('image') ) {
			$post = $this->input->post();
			unset($post['submit']);
			$data = $this->upload->data();
			//echo "<pre>";
			// print_r($data); //exit;
			$image_path = base_url("uploads/" . $data['raw_name'] . $data['file_ext']);
			// echo $image_path; exit;
			$post['image_path'] = $image_path;
			return $this->_falshAndRedirect(
					$this->articles->add_article($post),
					"Article Added Successully.",
					"Article Failed To Add, Please Try Again."
					);
		} else {
			$upload_error = $this->upload->display_errors();
			$this->load->view('admin/add_article',compact('upload_error'));
		}
	}

	public function edit_article($article_id)
	{
		$article = $this->articles->find_article($article_id);
		$this->load->view('admin/edit_article',['article'=>$article]);
	}

	public function update_article($article_id)
	{
		$this->load->library('form_validation');
		if( $this->form_validation->run('add_article_rules') ) {
			$post = $this->input->post();
			unset($post['submit']);
			return $this->_falshAndRedirect(
						$this->articles->update_article($article_id,$post),
						"Article Updated Successully.",
						"Article Failed To Update, Please Try Again."
					);
		} else {
			$this->load->view('admin/edit_article');
		}
	}

	public function delete_article()
	{
		$article_id = $this->input->post('article_id');

		return $this->_falshAndRedirect(
					$this->articles->delete_article($article_id),
					"Article Deleted Successully.",
					"Article Failed To Delete, Please Try Again."
				);
	}

	public function __construct()
	{
		parent::__construct();
		if( ! $this->session->userdata('user_id') )
			return redirect('login');
		$this->load->model('articlesmodel','articles');
		$this->load->helper('form');
	}

	private function _falshAndRedirect( $successful, $successMessage, $failureMessage )
	{
		if( $successful ) {
			$this->session->set_flashdata('feedback',$successMessage);
			$this->session->set_flashdata('feedback_class', 'alert-success');
		} else {
			$this->session->set_flashdata('feedback', $failureMessage);
			$this->session->set_flashdata('feedback_class', 'alert-danger');
		}
		return redirect('admin/dashboard');
	}
	
	
	public function profile()
	{
		$this->load->view('admin/user_profile');
	}
	
	public function edit_profile()
	{
		$this->load->view('admin/edit_profile');
	}
	
	public function update_profile()
	{
		$this->load->view('admin/update_profile');
	}
	
	public function update_profile_complete()
	{
		$user_id = $this->uri->segment(3);
		
		$this->load->library('form_validation');
		
		$config = [
			'upload_path'	=>		'./uploads/',
			'allowed_types'	=>		'jpg|gif|png|jpeg',
		];
		$this->load->library('upload', $config);
		
		if( $this->form_validation->run('profile') && $this->upload->do_upload('profile_pic') ) {
		
		$data = $this->upload->data();
		// echo "<pre>";
		// print_r($data); exit;
		$image_path = base_url("uploads/" . $data['raw_name'] . $data['file_ext']);
		// echo $image_path; 
		 //exit;
		$post['image_path'] = $image_path;
		
		$data = array(
			'email' 		=>  $this->input->post('email'),
			'uname' 		=>  $this->input->post('uname'),
			'fname'			=>  $this->input->post('fname'),
			'lname' 		=>  $this->input->post('lname'),
			'profile_pic' 	=>  $image_path
		);
		$this->load->model('updateprofilemodel');
		$this->updateprofilemodel->updateprofile($user_id, $data);
		
		
		redirect('admin/profile');
		} else {
			$upload_errors = $this->upload->display_errors();
			$this->load->view('admin/edit_profile',$upload_errors);
		}
	}
	
	public function add_user(){
		
		$this->load->helper('form');
		
		$this->load->view('admin/add_users.php');
		
	}
	public function user_insert()
	{	
		
		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');
		
		
		// $this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
		// $this->form_validation->set_rules(
        // 'uname', 'Username',
        // 'required|min_length[5]|max_length[12]|is_unique[users.uname]',
        // array(
                // 'required'      => 'You have not provided %s.',
                // 'is_unique'     => 'This %s already exists.'
				// )
		// );
		// $this->form_validation->set_rules('pword', 'Password', 'required');
		// $this->form_validation->set_rules('cpword', 'Password Confirmation', 'required|matches[pword]');
		// $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
		
		// if ($this->form_validation->run('signup') == FALSE)
			// {
				// $this->load->helper('form');
				// $this->load->view('public/user_registration');
			// }
		// else
			// {
				//print_r($_POST);
				$data = array(
					'id' 	=>  $this->input->post('id'),
					'email' =>  $this->input->post('email'),
					'uname' =>  $this->input->post('uname'),
					'pword' =>  $this->input->post('pword'),
					'cpword' =>  $this->input->post('cpword'),
					'fname' =>  $this->input->post('fname'),
					'lname' =>  $this->input->post('lname')
				);
				$this->load->library('email');
				$email = $this->input->post('email');
				
				$this->email->from('umakantsonwani@gmail.com', 'Umakant');
				$to_email = $this->email->to($email);
				//echo $to_email;
				//$this->email->cc('another@another-example.com');
				//$this->email->bcc('them@their-example.com');

				$this->email->subject('Email Test');
				$this->email->message('Testing the email class.');
				//echo $email_msg = $this->email->message('Testing the email class.');
				//exit();
				
				$this->email->send();
				
				$this->load->model('registrationmodel');

				$this->registrationmodel->insertUser($data);
				
				redirect('admin/view_users');
			// }
 
	}	
	public function view_users() 
	{
		//echo 'View users';
		$this->load->view('admin/view_users.php');
		//$this->load->helper('form');
		//$this->load->view('public/registration_successful');
	}
	
	// public function display_doforget()
	 // {
		// $data="";
		// $this->load->view('user/forgetpassword',$data);
	 // }
	 // public function doforget()
	 // {
		 // $this->load->helper('url');
		 // $email= $this->input->post('email');
		 // $this->load->library('form_validation');
		 // $this->form_validation->set_rules('email','email','required|xss_clean|trim');
	 // if ($this->form_validation->run() == FALSE)
	 // {
	 
		// $this->load->view('public/forgetpassword');
	 
	 // }
	 // else
	 // {
		// $q = $this->db->query("select * from users where email='" . $email . "'");
			// // if ($q->num_rows >0 ) {
				// // $r = $q->result();
				// // $user=$r[];
		 // // $this->load->helper('string');
		 // // $password= random_string('alnum',6);
		 // // $this->db->where('user_id', $user->user_id);
		 // // $this->db->update('users',array('pword'=>$password,'pass_encryption'=>MD5($password)));
		 // // $this->load->library('email');
		 // // $this->email->from('contact@example.com', 'sampletest');
		 // // $this->email->to($user->emailid); 
		 // // $this->email->subject('Password reset');
		 // // $this->email->message('You have requested the new password, Here is you new password:'. $password); 
		 // // $this->email->send();
		 // // $this->session->set_flashdata('message','Password has been reset and has been sent to email'); 
		// // redirect('user/display_doforget');
		// // }
		// // }
	 // }
}