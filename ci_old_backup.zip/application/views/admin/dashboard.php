
<?php include_once('admin_header.php'); ?>

                    <aside class="right-side">
<?php 
						$user_id = $this->session->userdata('user_id');
						$q = $this->db->select('country')
									  ->get('users');
						$data = $q->result_array(); 
						 // echo '<pre>';
						// print_r($data);
						// // //$val = array_count_values($data);
						// // //print_r($val);
						 // echo '</pre>';
						
						$user_meta = $this->db->select('meta_value')
											  ->where('meta_key','billing_country')
									          ->get('ci_usermeta');
						$user_data = $user_meta->result_array(); 
						//echo '<pre>';
						//print_r($user_data);
						//echo '</pre>';
						
						
						
					?>	
					
					<?php foreach($user_data as $key=>$value){
							$arr[] =  $value['meta_value'];
							//echo $key;
							//$country_fre = array_count_values($post['country']);
							//print_r($country_fre);
					 }
					 $val = array_count_values($arr);
					 //print_r($val);
					 //print $val_data = json_encode($val);
					   // foreach($val as $key=>$value){
						 // echo "['".$key."'".",".$value.",'http://www.google.com']";
						 // echo ",";
					 // }
						//echo join($val, ',');
					 ?>
					 
					<?php 
					
						
					$order_meta = $this->db->select('post_date')
										  ->where('post_type','shop_order') 
										  ->where('post_date >','2016-01-01') 
										  ->order_by('post_date','ASC')
										  ->get('order_posts');
					$order_data = $order_meta->result_array();
					 ?>
					 
					 
					 <?php 
						 $sql= "SELECT order_item_name FROM `ci_order_items` ;";
					 
							$query	= $this->db->query($sql);
							$res = $query->result_array(); 
							// echo '<pre>';
							// print_r($res);
							// echo '</pre>';
							//print_r(array_count_values($res));
							//echo $res[0]['cnt'];
						// Completed
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE post_date > '2016-01-01' AND  post_type='shop_order' AND post_status='wc-completed';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_completed = 80; 
						
						// Pending						
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-pending';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_pending = $res[0]['cnt'];
						
						// Processing
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-processing';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_processing = $res[0]['cnt'];
						
						// Processing
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-processing';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_processing = $res[0]['cnt'];
						
						// On Hold
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-on-hold';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_on_hold = $res[0]['cnt'];

						// Cancelled
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-cancelled';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_cancelled = $res[0]['cnt'];

						// Refunded
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-refunded';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_refunded = $res[0]['cnt'];
						
						// Failed
						$sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_type='shop_order' AND post_status='wc-failed';";

						$query	= $this->db->query($sql);
						$res = $query->result_array(); //print_r($res);
						$order_failed = $res[0]['cnt'];
						
					 ?>	
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>		 
					<script>
					 $(function () {
						
						$('#dialog_line_chart').dialog({
							autoOpen: false,
							show: {
								effect: 'blind',
								duration: 1000
							},
							hide: {
								effect: 'explode',
								duration: 1000
							}
						});
						$('#dialog_pie_chart').dialog({
							autoOpen: false,
							show: {
								effect: 'blind',
								duration: 1000
							},
							hide: {
								effect: 'explode',
								duration: 1000
							}
						});
						$('#dialog_bar_chart').dialog({
							autoOpen: false,
							show: {
								effect: 'blind',
								duration: 1000
							},
							hide: {
								effect: 'explode',
								duration: 1000
							}
						});
						 //Bar Chart
						$('#bar-chart').highcharts({
							chart: {
								type: 'column',
								options3d: {
									enabled: true,
									alpha: 10,
									beta: 5,
									depth: 70
								}
							},
							credits: {
								   enabled: false
							},
							title: {
								text: 'Orders in 2016'
							},
							plotOptions: {
								series: {
									point: {
										events: {
											click: function() {
												//alert('Person who like' + this.options.name + ' ' + this.y);
												$('#dialog_bar_chart').dialog('open');
												//alert('Person who like' + options.name + ' ' + options.personName);
											}
										}
									},
									cursor: 'pointer',
									stacking: 'normal',
								},
								column: {
									depth: 25
								}
							},
							xAxis: {
								categories: Highcharts.getOptions().lang.shortMonths
							},
							yAxis: {
								title: {
									text: null
								}
							},
							series: [{
								name: 'Orders',
								data: [<?php for($i=1;$i<12;$i++)
						{
							if($i<10)
							{ $startD = '2016-0'.$i.'-01';  }
							else{  $startD='2016-'.$i.'-01';   }
							
							//$a_date = "2009-12-01";
							 $startE= date("Y-m-t", strtotime($startD));	
							 $sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_date BETWEEN '$startD' AND '$startE' AND   post_type='shop_order' ;";
					 
							$query	= $this->db->query($sql);
							$res = $query->result_array(); //print_r($res);
							echo $res[0]['cnt'].',';
						}
						 ?>]
							}]
						});
					});
						
					 </script>
						 	
					<script>
					 $(function () {
						 
					
						//Pie Chart
						$('#pie-chart').highcharts({
							
							chart: {
								type: 'pie',
								options3d: {
									enabled: true,
									alpha: 45,
									beta: 0
								}
							},
							credits: {
								   enabled: false
							},
							title: {
								text: 'Users Country %'
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									depth: 35,
									point: {
										events: {
											click: function() {
												$('#dialog_pie_chart').dialog('open');
												//alert('Person who like' + options.name + ' ' + options.personName);
											}
										}
									},
									dataLabels: {
										enabled: true,
										format: '{point.name}'
									}
								}
							},
							series: [{
								type: 'pie',
								name: 'Users Country',
								data: [
									<?php   
									foreach($val as $key=>$value){
										echo "['".$key."'".",".$value."]";
										echo ",";
									} ?>
								]
							}]
						});
						$('#line-chart').highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: 0,
								plotShadow: false
							},
							title: {
								text: 'Order Status 2016',
								align: 'center',
								verticalAlign: 'top',
								y: 60
							},
							credits: {
								   enabled: false
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									dataLabels: {
										enabled: true,
										distance: -50,
										style: {
											fontWeight: 'bold',
											color: 'white',
											textShadow: '0px 1px 2px black'
										}
									},
									point: {
										events: {
											click: function() {
												$('#dialog_line_chart').dialog('open');
												//alert('Person who like' + options.name + ' ' + options.personName);
											}
										}
									},
									startAngle: -90,
									endAngle: 90,
									center: ['50%', '75%']
								}
							},
							series: [{
								type: 'pie',
								name: 'Order Status',
								innerSize: '50%',
								data: [
									['Completed', <?php echo $order_completed; ?>],
									['Cancelled', <?php echo $order_cancelled; ?>],
									['Processing', <?php echo $order_processing; ?>],	
									['Refunded', <?php echo $order_refunded; ?>],
									['Failed', <?php echo $order_failed; ?>],
									{
										name: 'Proprietary or Undetectable',
										y: 0.2,
										dataLabels: {
											enabled: false
										}
									}
								]
							}]
						});
						
						
					$('#line-bar').highcharts({
						chart: {
							type: 'line'
						},
						title: {
							text: 'Monthly Average Orders'
						},
						xAxis: {
							categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
						},
						yAxis: {
							title: {
								text: 'Orders'
							}
						},
						plotOptions: {
							line: {
								dataLabels: {
									enabled: true
								},
								enableMouseTracking: false
							}
						},
						series: [{
							name: 'Order',
							data: [<?php for($i=1;$i<12;$i++)
						{
							if($i<10)
							{ $startD = '2016-0'.$i.'-01';  }
							else{  $startD='2016-'.$i.'-01';   }
							
							//$a_date = "2009-12-01";
							 $startE= date("Y-m-t", strtotime($startD));	
							 $sql= "SELECT COUNT(post_date) as cnt FROM `order_posts` WHERE  post_date BETWEEN '$startD' AND '$startE' AND   post_type='shop_order' ;";
					 
							$query	= $this->db->query($sql);
							$res = $query->result_array(); //print_r($res);
							echo $res[0]['cnt'].',';
						}
						 ?>]
						}]
					});
						
					});
						
					 </script>
					
                        <div class="row">
							<div class="col-md-6">
								<div id="line-chart"></div>
							</div>
							<div class="col-md-6">
								<div id="bar-chart"></div>
							</div>
						</div>
                        <div class="row">
							
							<div class="col-md-6">
								<div id="pie-chart"></div> 
							</div>
							<div class="col-md-6">
								<div id="line-bar"></div>
							</div>
						</div>
						
						<div id="dialog_line_chart" title="Basic dialog">
							<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
						</div>
						
						<div id="dialog_pie_chart" title="Basic dialog">
							<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
						</div>
						
						<div id="dialog_bar_chart" title="Basic dialog">
							<?php for($i=1;$i<12;$i++)
								{
									if($i<10)
									{ $startD = '2016-0'.$i.'-01';  }
									else{ $startD='2016-'.$i.'-01'; }
									
									//$a_date = "2009-12-01";
									 $startE= date("Y-m-t", strtotime($startD));	
									 $sql= "SELECT * FROM `order_posts` WHERE  post_date BETWEEN '$startD' AND '$startE' AND   post_type='shop_order' ;";
							 
									$query	= $this->db->query($sql);
									$res = $query->result_array(); //print_r($res);
									//print_r($res);
								}
							?>	
						</div>
						
                <!-- Main content -->
                <section class="content">

                   
                        <div class="col-md-12">
                          <section class="panel tasks-widget">
                              <header class="panel-heading">
                                  All List
                            </header>
                            <div class="panel-body">

                              <div class="task-content">
<?php if( count($articles) ):
			$count = $this->uri->segment(3, 0);
			foreach($articles as $article ): ?>
              <ul class="task-list">
				<li>
					<div class="task-checkbox"><?= ++$count ?></div>
					 <div class="task-title">
						  <span class="task-title-sp"><?= $article->title ?></span>
						  <div class="pull-right hidden-phone">
								<?= anchor("admin/edit_article/{$article->id}",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-default btn-xs']); ?>
							  
						<?=
						form_open('admin/delete_article'),
						form_hidden('article_id', $article->id),
						form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']),
						
						form_close();

					?>
						  </div>
					  </div>
				</li>
			</ul>
		<?php endforeach; ?>
	<?php else: ?>
			<ul class="task-list">
				<li>
					No Records Found.
				</li>
			</ul>
	<?php endif; ?>
	
<?= $this->pagination->create_links(); ?>

                              </div>

                              <div class=" add-task-row">
									<?= anchor('admin/store_article','Add Article',['class'=>'btn btn-success btn-sm pull-left']) ?>
                                  <a class="btn btn-default btn-sm pull-right" href="#">See All Tasks</a>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- row end -->
                </section><!-- /.content -->
                <div class="footer-main">
                    Copyright &copy Admin
                </div>
            </aside><!-- /.right-side -->
<?php include_once('admin_footer.php'); ?>
