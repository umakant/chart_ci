<?php include('public_header.php'); ?>

<div class="container">
	<h3>Registration Completed</h3>
	Go to Login Page <?= anchor('login','Click Here') ?> |	TRY it again <?= anchor('registration','Click Here') ?>
</div>

<?php include('public_footer.php'); ?>